import React, { useEffect, useMemo, useState } from "react";
import { listDrawings, getDrawing, deleteDrawing } from "../../api/drawingApi";
import {
    DEFAULT_GROUP,
    DEFAULT_TITLE,
    getStoredGroups,
    saveStoredGroup,
    deleteStoredGroup,
    mergeGroupsFromDrawings,
    getGroupNameFromDrawing,
} from "../DrawingGroupStore/drawingGroupStore";
import {
    deleteLocalDrawing,
    getLocalDrawingById,
    mergeLocalAndServerDrawings,
} from "../DrawingGroupStore/localDrawingStore";
import "./MyDrawingsPopup.css";

export default function MyDrawingsPopup({
                                            open,
                                            onClose,
                                            onOpenDrawing,
                                        }) {
    const [drawings, setDrawings] = useState([]);
    const [groups, setGroups] = useState([DEFAULT_GROUP]);
    const [selectedGroup, setSelectedGroup] = useState("All");
    const [searchText, setSearchText] = useState("");
    const [newGroupName, setNewGroupName] = useState("");
    const [showNewGroup, setShowNewGroup] = useState(false);
    const [loading, setLoading] = useState(false);
    const [openingId, setOpeningId] = useState(null);
    const [deletingId, setDeletingId] = useState(null);
    const [message, setMessage] = useState("");

    const getGroupName = (drawing) => getGroupNameFromDrawing(drawing);

    const normalizeRows = (rows) => {
        return rows.map((drawing) => ({
            ...drawing,
            groupName: getGroupNameFromDrawing(drawing),
        }));
    };

    const loadDrawings = async () => {
        setLoading(true);
        setMessage("");

        try {
            const data = await listDrawings();

            const rows = Array.isArray(data)
                ? data
                : Array.isArray(data?.data)
                    ? data.data
                    : Array.isArray(data?.drawings)
                        ? data.drawings
                        : [];

            const normalizedRows = normalizeRows(rows);
            const mergedRows = mergeLocalAndServerDrawings(normalizedRows);

            setDrawings(mergedRows);
            setGroups(mergeGroupsFromDrawings(mergedRows));
        } catch (error) {
            console.error("Failed to load server drawings", error);

            const localOnlyRows = mergeLocalAndServerDrawings([]);

            setDrawings(localOnlyRows);
            setGroups(
                localOnlyRows.length
                    ? mergeGroupsFromDrawings(localOnlyRows)
                    : getStoredGroups()
            );

            setMessage("Showing local drawings. Server drawings could not be loaded.");
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (open) {
            setSelectedGroup("All");
            setSearchText("");
            setNewGroupName("");
            setShowNewGroup(false);
            setGroups(getStoredGroups());
            loadDrawings();
        }
    }, [open]);

    const sidebarGroups = useMemo(() => {
        const uniqueGroups = Array.from(new Set([DEFAULT_GROUP, ...(groups || [])]));
        return ["All", ...uniqueGroups];
    }, [groups]);

    const filteredDrawings = useMemo(() => {
        const q = searchText.trim().toLowerCase();

        return drawings.filter((drawing) => {
            const title = drawing.title || DEFAULT_TITLE;
            const group = getGroupName(drawing);

            const groupOk = selectedGroup === "All" || selectedGroup === group;
            const searchOk =
                !q ||
                title.toLowerCase().includes(q) ||
                group.toLowerCase().includes(q);

            return groupOk && searchOk;
        });
    }, [drawings, selectedGroup, searchText]);

    if (!open) return null;

    const countForGroup = (group) => {
        if (group === "All") return drawings.length;
        return drawings.filter((drawing) => getGroupName(drawing) === group).length;
    };

    const handleAddGroup = () => {
        const name = newGroupName.trim();
        if (!name) return;

        const next = saveStoredGroup(name);

        setGroups(next);
        setSelectedGroup(name);
        setNewGroupName("");
        setShowNewGroup(false);
        setMessage("");
    };

    const handleDeleteGroup = (event, group) => {
        event.stopPropagation();

        if (group === "All" || group === DEFAULT_GROUP) {
            return;
        }

        const drawingsCount = countForGroup(group);

        const ok = window.confirm(
            drawingsCount > 0
                ? `Delete group "${group}" from sidebar? Drawings will not be deleted. They will still appear in All.`
                : `Delete group "${group}"?`
        );

        if (!ok) return;

        const nextGroups = deleteStoredGroup(group);

        setGroups(nextGroups);

        if (selectedGroup === group) {
            setSelectedGroup("All");
        }

        setMessage(`Group "${group}" deleted. Drawings were not deleted.`);
    };

    const handleOpen = async (drawing) => {
        if (!drawing?.id) {
            setMessage("Drawing id missing.");
            return;
        }

        setOpeningId(drawing.id);
        setMessage("");

        try {
            if (drawing.source === "local") {
                const localDrawing = getLocalDrawingById(drawing.id) || drawing;

                saveStoredGroup(getGroupNameFromDrawing(localDrawing));
                onOpenDrawing?.(localDrawing);
                onClose?.();
                return;
            }

            const fullDrawing = await getDrawing(drawing.id);

            const normalizedFullDrawing = {
                ...fullDrawing,
                groupName: getGroupNameFromDrawing(fullDrawing),
                source: "server",
            };

            saveStoredGroup(normalizedFullDrawing.groupName);

            onOpenDrawing?.(normalizedFullDrawing);
            onClose?.();
        } catch (error) {
            console.error("Open server drawing failed", error);

            const localDrawing = getLocalDrawingById(drawing.id);

            if (localDrawing) {
                saveStoredGroup(getGroupNameFromDrawing(localDrawing));
                onOpenDrawing?.(localDrawing);
                onClose?.();
                return;
            }

            setMessage(error?.message || "Failed to open drawing.");
        } finally {
            setOpeningId(null);
        }
    };

    const handleDelete = async (drawing) => {
        const drawingId = drawing?.id;

        if (!drawingId) {
            setMessage("Drawing id missing.");
            return;
        }

        const ok = window.confirm("Delete this drawing?");
        if (!ok) return;

        setDeletingId(drawingId);
        setMessage("");

        try {
            deleteLocalDrawing(drawingId);

            if (drawing.source !== "local") {
                await deleteDrawing(drawingId);
            }

            setDrawings((prev) =>
                prev.filter((d) => String(d.id) !== String(drawingId))
            );

            setMessage("Drawing deleted.");
        } catch (error) {
            console.error("Delete failed", error);

            setDrawings((prev) =>
                prev.filter((d) => String(d.id) !== String(drawingId))
            );

            setMessage("Deleted locally. Server delete failed.");
        } finally {
            setDeletingId(null);
        }
    };

    const formatDate = (drawing) => {
        const raw = drawing.updatedAt || drawing.createdAt || drawing.savedAt;
        if (!raw) return "No date";

        try {
            return new Date(raw).toLocaleString();
        } catch {
            return raw;
        }
    };

    return (
        <div className="drawings-backdrop" onMouseDown={onClose}>
            <div className="drawings-modal" onMouseDown={(e) => e.stopPropagation()}>
                <button className="drawings-close" type="button" onClick={onClose}>
                    ×
                </button>

                <aside className="drawings-sidebar">
                    <div className="drawings-logo-row">
                        <div className="drawings-logo">S</div>
                        <div>
                            <strong>SketchyDraw</strong>
                            <span>Drawing Library</span>
                        </div>
                    </div>

                    <div className="drawings-sidebar-head">
                        <span>Groups</span>
                        <button type="button" onClick={() => setShowNewGroup((v) => !v)}>
                            +
                        </button>
                    </div>

                    {showNewGroup && (
                        <div className="drawings-new-group">
                            <input
                                value={newGroupName}
                                onChange={(e) => setNewGroupName(e.target.value)}
                                placeholder="New group"
                                onKeyDown={(e) => {
                                    if (e.key === "Enter") {
                                        handleAddGroup();
                                    }
                                }}
                            />
                            <button type="button" onClick={handleAddGroup}>
                                Add
                            </button>
                        </div>
                    )}

                    <div className="drawings-group-list">
                        {sidebarGroups.map((group) => {
                            const canDeleteGroup =
                                group !== "All" && group !== DEFAULT_GROUP;

                            return (
                                <div
                                    key={group}
                                    className={`drawings-group-row ${
                                        selectedGroup === group ? "active" : ""
                                    }`}
                                >
                                    <button
                                        type="button"
                                        className="drawings-group-select"
                                        onClick={() => setSelectedGroup(group)}
                                    >
                                        <span>{group}</span>
                                        <em>{countForGroup(group)}</em>
                                    </button>

                                    {canDeleteGroup && (
                                        <button
                                            type="button"
                                            className="drawings-group-delete"
                                            title="Delete group"
                                            aria-label={`Delete group ${group}`}
                                            onClick={(event) => handleDeleteGroup(event, group)}
                                        >
                                            🗑
                                        </button>
                                    )}
                                </div>
                            );
                        })}
                    </div>

                    <div className="drawings-version-card">
                        <strong>Local backup active</strong>
                        <p>Your drawings are saved in this browser also.</p>
                    </div>
                </aside>

                <main className="drawings-main">
                    <header className="drawings-header">
                        <div>
                            <span>Your saved diagrams</span>
                            <h2>My Drawings</h2>
                            <p>Open, filter and manage drawings by group.</p>
                        </div>

                        <button type="button" onClick={loadDrawings} disabled={loading}>
                            {loading ? "Refreshing..." : "Refresh"}
                        </button>
                    </header>

                    <div className="drawings-toolbar">
                        <input
                            value={searchText}
                            onChange={(e) => setSearchText(e.target.value)}
                            placeholder="Search by title or group..."
                        />

                        <div className="drawings-count">
                            {filteredDrawings.length} shown
                        </div>
                    </div>

                    {message && <div className="drawings-message">{message}</div>}

                    {loading && (
                        <div className="drawings-grid">
                            {[1, 2, 3, 4, 5, 6].map((n) => (
                                <div className="drawing-card skeleton" key={n}>
                                    <div />
                                    <span />
                                    <span />
                                </div>
                            ))}
                        </div>
                    )}

                    {!loading && filteredDrawings.length === 0 && (
                        <div className="drawings-empty">
                            <div>◇</div>
                            <strong>No drawings found</strong>
                            <span>Save a drawing or select another group.</span>
                        </div>
                    )}

                    {!loading && filteredDrawings.length > 0 && (
                        <div className="drawings-grid">
                            {filteredDrawings.map((drawing) => {
                                const isOpening = openingId === drawing.id;
                                const isDeleting = deletingId === drawing.id;

                                return (
                                    <article className="drawing-card" key={drawing.id}>
                                        <div className="drawing-preview">
                                            <span />
                                            <span />
                                            <span />
                                        </div>

                                        <div className="drawing-card-body">
                                            <div className="drawing-badges">
                                                <em>{getGroupName(drawing)}</em>
                                                <b>
                                                    {drawing.source === "local"
                                                        ? "Local"
                                                        : `v${drawing.latestVersion || drawing.version || 1}`}
                                                </b>
                                            </div>

                                            <h3 title={drawing.title || DEFAULT_TITLE}>
                                                {drawing.title || DEFAULT_TITLE}
                                            </h3>

                                            <p>{formatDate(drawing)}</p>

                                            <div className="drawing-actions">
                                                <button
                                                    type="button"
                                                    onClick={() => handleOpen(drawing)}
                                                    disabled={isOpening || isDeleting}
                                                >
                                                    {isOpening ? "Opening..." : "Open"}
                                                </button>

                                                <button
                                                    type="button"
                                                    className="danger"
                                                    onClick={() => handleDelete(drawing)}
                                                    disabled={isOpening || isDeleting}
                                                >
                                                    {isDeleting ? "..." : "Delete"}
                                                </button>
                                            </div>
                                        </div>
                                    </article>
                                );
                            })}
                        </div>
                    )}
                </main>
            </div>
        </div>
    );
}