import React from "react";
import { THREE_D_MOTIONS, THREE_D_PRIMITIVES } from "./threeDConstants";
import "./ThreeD.css";

const NATIVE_3D_EASINGS = [
    { value: "linear", label: "Linear" },
    { value: "inOut", label: "Cubic smooth in/out" },
    { value: "out", label: "Cubic ease out" },
    { value: "in", label: "Cubic ease in" },
];

function NumberField({ label, value, onChange, min, step }) {
    return (
        <label>
            <span>{label}</span>
            <input
                type="number"
                value={Number(value || 0)}
                min={min}
                step={step}
                onChange={(event) => onChange?.(Number(event.target.value) || 0)}
            />
        </label>
    );
}

export default function ThreeDPropertiesSection({ element, onPatch }) {
    if (!element) return null;

    const primitive = element.primitive3d || "box";
    const dsaPrimitive = ["array3d", "matrix3d", "linkedlist3d", "stack3d", "queue3d", "tree3d", "heap3d", "minheap3d", "maxheap3d", "graph3d", "intervals3d", "hashtable3d", "trie3d", "sorting3d"].includes(primitive);
    const aiPrimitive = ["neuron3d", "neuralnetwork3d", "tensor3d", "embedding3d", "attention3d", "transformer3d", "tokenflow3d", "convnet3d", "modelpipeline3d", "rnn3d", "autoencoder3d", "gan3d", "diffusion3d", "rag3d", "vectordb3d", "losslandscape3d"].includes(primitive);
    const characterPrimitive = ["boywalk3d", "boyrun3d", "girlwalk3d", "girlrun3d"].includes(primitive);

    return (
        <>
            <div className="property-section">
                <label>3D primitive</label>
                <select
                    value={primitive}
                    onChange={(event) => onPatch?.({ primitive3d: event.target.value })}
                >
                    {THREE_D_PRIMITIVES.map(({ value, label }) => (
                        <option key={value} value={value}>{label}</option>
                    ))}
                </select>
            </div>

            <div className="property-section">
                <label>3D position</label>
                <div className="webgl-number-grid">
                    <NumberField label="X" value={element.x} onChange={(value) => onPatch?.({ x: value })} />
                    <NumberField label="Y" value={element.y} onChange={(value) => onPatch?.({ y: value })} />
                    <NumberField label="Z" value={element.z} onChange={(value) => onPatch?.({ z: value })} />
                </div>
                <div className="three-d-depth-actions">
                    <button type="button" onClick={() => onPatch?.({ z: (Number(element.z) || 0) - 10 })}>Send backward</button>
                    <button type="button" onClick={() => onPatch?.({ z: 0 })}>Reset depth</button>
                    <button type="button" onClick={() => onPatch?.({ z: (Number(element.z) || 0) + 10 })}>Bring forward</button>
                </div>
                <div className="webgl-character-grid">
                    <label>
                        <span>Cubic easing</span>
                        <select value={element.motionEasing || "inOut"} onChange={(event) => onPatch?.({ motionEasing: event.target.value })}>
                            {NATIVE_3D_EASINGS.map(({ value, label }) => <option key={value} value={value}>{label}</option>)}
                        </select>
                    </label>
                    <label>
                        <span>Direction</span>
                        <select value={element.motionDirection || "alternate"} onChange={(event) => onPatch?.({ motionDirection: event.target.value })}>
                            <option value="normal">Normal</option>
                            <option value="reverse">Reverse</option>
                            <option value="alternate">Alternate</option>
                        </select>
                    </label>
                </div>
                <NumberField label="Motion duration (ms)" value={element.motionDurationMs || 2400} min="100" step="100" onChange={(value) => onPatch?.({ motionDurationMs: Math.max(100, value || 2400) })} />
            </div>

            <div className="property-section">
                <label>Rotation</label>
                <div className="webgl-number-grid">
                    <NumberField label="X°" value={element.rotationX} step="1" onChange={(value) => onPatch?.({ rotationX: value })} />
                    <NumberField label="Y°" value={element.rotationY} step="1" onChange={(value) => onPatch?.({ rotationY: value })} />
                    <NumberField label="Z°" value={element.rotationZ} step="1" onChange={(value) => onPatch?.({ rotationZ: value })} />
                </div>
                <p className="three-d-orbit-help">Ctrl-drag (Cmd-drag on Mac) directly on the object to orbit.</p>
                <button className="three-d-reset-camera" type="button" onClick={() => onPatch?.({ cameraYaw: 0, cameraPitch: 12 })}>Reset camera</button>
            </div>

            <div className="property-section">
                <label>Geometry</label>
                <div className="webgl-number-grid">
                    <NumberField label="Depth" value={element.depth || 70} min="1" onChange={(value) => onPatch?.({ depth: Math.max(1, value || 1) })} />
                    <NumberField label="Scale" value={element.scale3d || 1} min="0.1" step="0.1" onChange={(value) => onPatch?.({ scale3d: Math.max(0.1, value || 1) })} />
                    <NumberField label="Gap" value={element.gap || 0} min="0" onChange={(value) => onPatch?.({ gap: Math.max(0, value || 0) })} />
                </div>
            </div>

            <div className="property-section three-d-motion-section">
                <label>Live 3D motion</label>
                <div className="webgl-character-grid">
                    <label>
                        <span>Motion</span>
                        <select value={element.motion3d || "none"} onChange={(event) => onPatch?.({ motion3d: event.target.value })}>
                            {THREE_D_MOTIONS.map(({ value, label }) => <option key={value} value={value}>{label}</option>)}
                        </select>
                    </label>
                    <NumberField label="Speed" value={element.motionSpeed || 1} min="0.05" step="0.1" onChange={(value) => onPatch?.({ motionSpeed: Math.max(.05, value || 1) })} />
                </div>
                <div className="webgl-number-grid">
                    <NumberField label="Perspective" value={element.perspective || 720} min="180" step="20" onChange={(value) => onPatch?.({ perspective: Math.max(180, value || 720) })} />
                    <NumberField label="Camera pitch" value={element.cameraPitch || 12} step="1" onChange={(value) => onPatch?.({ cameraPitch: value })} />
                    <NumberField label="Camera yaw" value={element.cameraYaw || 0} step="1" onChange={(value) => onPatch?.({ cameraYaw: value })} />
                </div>
                <label className="three-d-check-row">
                    <input type="checkbox" checked={element.showLabels !== false} onChange={(event) => onPatch?.({ showLabels: event.target.checked })} />
                    <span>Show labels and values</span>
                </label>
            </div>

            <div className="property-section">
                <label>WebGL camera & lighting</label>
                <div className="webgl-character-grid">
                    <label><span>Projection</span><select value={element.projection3d || "orthographic"} onChange={(event) => onPatch?.({ projection3d: event.target.value })}><option value="orthographic">Orthographic · aligned</option><option value="perspective">Perspective · depth</option></select></label>
                    <label><span>Lighting</span><select value={element.lightingPreset || "studio"} onChange={(event) => onPatch?.({ lightingPreset: event.target.value })}><option value="studio">Studio</option><option value="soft">Soft</option><option value="blueprint">Blueprint</option><option value="neon">Neon</option><option value="dark">Dark course</option></select></label>
                </div>
                <div className="webgl-number-grid">
                    <NumberField label="FOV" value={element.cameraFov || 50} min="20" step="1" onChange={(value) => onPatch?.({ cameraFov: Math.max(20, Math.min(100, value)) })} />
                    <NumberField label="Distance" value={element.cameraDistance || 900} min="200" step="20" onChange={(value) => onPatch?.({ cameraDistance: Math.max(200, value) })} />
                    <NumberField label="Explode" value={element.exploded3d || 0} min="0" step="10" onChange={(value) => onPatch?.({ exploded3d: Math.max(0, value) })} />
                </div>
                <div className="webgl-number-grid">
                    <NumberField label="Orbit yaw" value={element.cameraYaw || 0} step="1" onChange={(value) => onPatch?.({ cameraYaw: value })} />
                    <NumberField label="Orbit pitch" value={element.cameraPitch || 12} step="1" onChange={(value) => onPatch?.({ cameraPitch: Math.max(-85, Math.min(85, value)) })} />
                    <NumberField label="Target Z" value={element.cameraTargetZ || 0} step="10" onChange={(value) => onPatch?.({ cameraTargetZ: value })} />
                </div>
                <div className="three-d-depth-actions">
                    <button type="button" onClick={() => {
                        const keys = Array.isArray(element.orbitKeyframes) ? element.orbitKeyframes : [];
                        const timeMs = keys.length ? (Number(keys[keys.length - 1].timeMs) || 0) + 1000 : 0;
                        onPatch?.({ orbitKeyframes: [...keys, { timeMs, yaw: element.cameraYaw || 0, pitch: element.cameraPitch || 12, distance: element.cameraDistance || 900, targetX: element.cameraTargetX || 0, targetY: element.cameraTargetY || 0, targetZ: element.cameraTargetZ || 0 }] });
                    }}>+ Camera orbit key</button>
                    <button type="button" onClick={() => onPatch?.({ orbitKeyframes: [] })}>Clear orbit</button>
                    <button type="button" onClick={() => onPatch?.({ exploded3d: element.exploded3d ? 0 : 180 })}>{element.exploded3d ? "Assemble" : "Explode"}</button>
                </div>
            </div>

            <div className="property-section">
                <label>3D transform keyframes</label>
                <div className="three-d-depth-actions">
                    <button type="button" onClick={() => {
                        const keys = Array.isArray(element.transformKeyframes) ? element.transformKeyframes : [];
                        const timeMs = keys.length ? (Number(keys[keys.length - 1].timeMs) || 0) + 1000 : 0;
                        onPatch?.({ transformKeyframes: [...keys, { timeMs, x: element.x, y: element.y, z: element.z, rotationX: element.rotationX, rotationY: element.rotationY, rotationZ: element.rotationZ, scale3d: element.scale3d, opacity: element.opacity, materialColor: element.materialColor || element.fill }] });
                    }}>+ Transform key</button>
                    <button type="button" onClick={() => onPatch?.({ transformKeyframes: [] })}>Clear keys</button>
                    <button type="button" onClick={() => onPatch?.({ dataPath3d: [{ x: -80, y: 0, z: 20 }, { x: 0, y: -60, z: 80 }, { x: 80, y: 0, z: 20 }], pathDurationMs: 2200 })}>Add flow path</button>
                </div>
                <small className="property-help">Move/rotate the object, then add another key. Values interpolate during playback. In Perspective mode, orbit keys move the real WebGL camera and export identically.</small>
                <label><span>Animated material colour</span><input type="color" value={element.materialColor || element.fill || "#e2e8f0"} onChange={(event) => onPatch?.({ materialColor: event.target.value })}/></label>
            </div>

            {Array.isArray(element.codeSteps) && element.codeSteps.length > 0 && (
                <div className="property-section">
                    <label>Code-synchronised steps</label>
                    <NumberField label="Step duration (ms)" value={element.stepDurationMs || 900} min="100" step="100" onChange={(value) => onPatch?.({ stepDurationMs: Math.max(100, value) })} />
                    <div className="three-d-code-step-list">{element.codeSteps.map((step, index) => <button type="button" key={`${step.index || index}-${step.line}`} onClick={() => window.dispatchEvent(new CustomEvent("sketchydraw:3d-step", { detail: { action: "seek", elementId: element.id, timeMs: index * (element.stepDurationMs || 900) } }))}>{index + 1}. {step.line}</button>)}</div>
                    <textarea rows="6" value={JSON.stringify(element.codeSteps, null, 2)} onChange={(event) => { try { onPatch?.({ codeSteps: JSON.parse(event.target.value) }); } catch (_) { /* Keep the last valid line-to-object mapping. */ } }} />
                    <small className="property-help">Map each line with targetIndex/targetId and action: highlight, swap, insert, extract or visit.</small>
                    <div className="three-d-depth-actions">
                    <button type="button" onClick={() => window.dispatchEvent(new CustomEvent("sketchydraw:3d-step", { detail: { action: "previous", elementId: element.id, durationMs: element.stepDurationMs || 900 } }))}>◀ Step</button>
                    <button type="button" onClick={() => window.dispatchEvent(new CustomEvent("sketchydraw:3d-step", { detail: { action: "toggle", elementId: element.id } }))}>Play / pause</button>
                    <button type="button" onClick={() => window.dispatchEvent(new CustomEvent("sketchydraw:3d-step", { detail: { action: "next", elementId: element.id, durationMs: element.stepDurationMs || 900 } }))}>Step ▶</button>
                    </div>
                </div>
            )}


            {characterPrimitive && (
                <div className="property-section">
                    <label>Character animation</label>
                    <div className="webgl-character-grid">
                        <label>
                            <span>Action</span>
                            <select
                                value={element.characterAction || "idle"}
                                onChange={(event) => onPatch?.({ characterAction: event.target.value })}
                            >
                                <option value="idle">Idle</option>
                                <option value="walk">Walk</option>
                                <option value="run">Run</option>
                            </select>
                        </label>
                        <NumberField
                            label="Speed"
                            value={element.characterSpeed || 1}
                            min="0.1"
                            step="0.1"
                            onChange={(value) => onPatch?.({ characterSpeed: Math.max(0.1, value || 1) })}
                        />
                    </div>
                </div>
            )}

            {dsaPrimitive && (
                <div className="property-section">
                    <label>DSA data</label>
                    {primitive === "graph3d" && (
                        <>
                            <textarea rows="4" value={JSON.stringify(element.graphNodes || [], null, 2)} onChange={(event) => { try { onPatch?.({ graphNodes: JSON.parse(event.target.value) }); } catch (_) { /* Keep current graph until JSON is valid. */ } }} />
                            <textarea rows="3" value={JSON.stringify(element.graphEdges || [])} onChange={(event) => { try { onPatch?.({ graphEdges: JSON.parse(event.target.value) }); } catch (_) { /* Keep current graph until JSON is valid. */ } }} />
                            <textarea rows="2" value={JSON.stringify(element.traversalOrder || [])} onChange={(event) => { try { onPatch?.({ traversalOrder: JSON.parse(event.target.value) }); } catch (_) { /* Keep current graph until JSON is valid. */ } }} />
                            <select value={element.traversalMode || "BFS"} onChange={(event) => onPatch?.({ traversalMode: event.target.value })}>
                                <option value="BFS">BFS traversal</option>
                                <option value="DFS">DFS traversal</option>
                            </select>
                        </>
                    )}
                    {primitive === "intervals3d" && (
                        <textarea rows="3" value={JSON.stringify(element.intervals || [[1, 4], [2, 6], [5, 8]])} onChange={(event) => { try { onPatch?.({ intervals: JSON.parse(event.target.value) }); } catch (_) { /* Keep current intervals until JSON is valid. */ } }} />
                    )}
                    {["heap3d", "minheap3d", "maxheap3d"].includes(primitive) && (
                        <textarea rows="3" value={JSON.stringify(element.heapValues || element.values || [])} onChange={(event) => { try { onPatch?.({ heapValues: JSON.parse(event.target.value) }); } catch (_) { /* Keep current heap until JSON is valid. */ } }} />
                    )}
                    <textarea
                        rows="3"
                        value={Array.isArray(element.values) ? JSON.stringify(element.values) : "[]"}
                        onChange={(event) => {
                            try {
                                onPatch?.({ values: JSON.parse(event.target.value) });
                            } catch (_) {
                                // Keep the current object unchanged while the JSON is temporarily invalid.
                            }
                        }}
                    />
                </div>
            )}

            {aiPrimitive && (
                <div className="property-section">
                    <label>AI structure data</label>
                    {primitive === "neuralnetwork3d" && (
                        <textarea rows="2" value={JSON.stringify(element.layers || [3, 5, 5, 2])} onChange={(event) => { try { onPatch?.({ layers: JSON.parse(event.target.value) }); } catch (_) { /* Keep current value until JSON is valid. */ } }} />
                    )}
                    {primitive === "tensor3d" && (
                        <textarea rows="2" value={JSON.stringify(element.tensorShape || [4, 4, 3])} onChange={(event) => { try { onPatch?.({ tensorShape: JSON.parse(event.target.value) }); } catch (_) { /* Keep current value until JSON is valid. */ } }} />
                    )}
                    {primitive === "tokenflow3d" && (
                        <textarea rows="2" value={JSON.stringify(element.tokens || ["The", "model", "learns", "patterns"])} onChange={(event) => { try { onPatch?.({ tokens: JSON.parse(event.target.value) }); } catch (_) { /* Keep current value until JSON is valid. */ } }} />
                    )}
                    {(primitive === "attention3d" || primitive === "embedding3d") && (
                        <NumberField label={primitive === "attention3d" ? "Matrix size" : "Point count"} value={primitive === "attention3d" ? element.rows || 6 : element.nodes || 30} min="3" step="1" onChange={(value) => onPatch?.(primitive === "attention3d" ? { rows: value, cols: value } : { nodes: value })} />
                    )}
                    <small className="property-help">Use JSON arrays to change layers, tensor shape, tokens, or values.</small>
                </div>
            )}
        </>
    );
}
