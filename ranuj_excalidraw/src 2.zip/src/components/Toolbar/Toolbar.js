import React, { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import "./Toolbar.css";
import { SOCIAL_MEDIA_PRESETS } from "../../utils/socialMediaPresets";
import { requestProUpgrade } from "../../utils/proFeatureGate";
import { Pencil, Square, Circle, Slash, MousePointer2, Eraser, Type, MoveRight, Diamond, Hand, Image as ImageIcon, UserRound, MoreHorizontal, Film, Zap } from "lucide-react";

import {
    getUser,
    isLoggedIn,
    logout,
    isProUser,
    mergeSubscriptionIntoUser,
    updateLocalUserProfile,
} from "../../utils/auth";

import SketchyLoginModal from "../SketchyLoginModal/SketchyLoginModal";
import SubscriptionPopup from "../SubscriptionPopup/SubscriptionPopup";

import { getActiveAnnouncement } from "../../api/announcementApi";
import { getSubscriptionStatus, getPaymentHistory } from "../../api/paymentApi";
import { getMyProfile, updateMyProfile } from "../../api/authApi";
import {
    DEFAULT_NOTEBOOK_PAGE_COUNT,
    MAX_NOTEBOOK_PAGE_COUNT,
} from "../../canvas/notebook/notebookPageConstants";
import {
    ANIMATION_EXPORT_RESOLUTION_OPTIONS,
    ANIMATION_EXPORT_TEXT_SCALE_OPTIONS,
    ANIMATION_EXPORT_ZOOM_OPTIONS,
    getAnimationExportFitZoomPercent,
    resolveAnimationExportSize,
} from "../../canvas/animationExportSettings";

const TOOLBAR_TOOLS = [
    { id: "select", label: "Select", icon: MousePointer2 },
    { id: "hand", label: "Hand", icon: Hand },
    { id: "pencil", label: "Pencil", icon: Pencil },
    { id: "line", label: "Line", icon: Slash },
    { id: "arrow", label: "Arrow", icon: MoveRight },
    { id: "rect", label: "Rectangle", icon: Square },
    { id: "diamond", label: "Diamond", icon: Diamond },
    { id: "ellipse", label: "Ellipse", icon: Circle },
    { id: "user", label: "User", icon: UserRound, premium: true },
    { id: "text", label: "Text", icon: Type },
    { id: "image", label: "Image", icon: ImageIcon, premium: true },
    { id: "eraser", label: "Eraser", icon: Eraser },
];

export default function Toolbar({
                                    undo,
                                    redo,
                                    clearCanvas,
                                    canUndo,
                                    canRedo,
                                    showGrid,
                                    setShowGrid,
                                    canvasProps,
                                    updateCanvasProps,
                                    exportPNG,
                                    exportInstagram,
                                    exportJPEG,
                                    exportSVG,
                                    exportPDF,
                                    printCanvas,
                                    exportJSON,
                                    exportPPT,
                                    exportExcel,
                                    exportCSV,
                                    exportProtectedDrawing,
                                    openJsonPicker,
                                    openImportPicker,
                                    createNewDrawing,
                                    drawingTitle,
                                    onDrawingTitleChange,
                                    timelineFrames = [],
                                    canvasSize = { width: 1200, height: 700 },
                                    currentFrameIndex = 0,
                                    onPresentFrames,
                                    onPreviousFrame,
                                    onNextFrame,
                                    openFramesPanel,
                                    exportGIF,
                                    gifExporting = false,
                                    gifExportProgress = 0,
                                    playbackSpeed = 0.5,
                                    onPlaybackSpeedChange,
                                    videoBackendSpeed = 1,
                                    onVideoBackendSpeedChange,
                                    exportResolution = "1920x1080",
                                    onExportResolutionChange,
                                    exportZoomPercent = 150,
                                    onExportZoomPercentChange,
                                    exportFitContent = true,
                                    onExportFitContentChange,
                                    exportCameraPan = { x: 0, y: 0 },
                                    onExportCameraPanChange,
                                    exportTextScalePercent = 125,
                                    onExportTextScalePercentChange,
                                    socialCreatorPreset = null,
                                    setSocialCreatorPreset,
                                    onToggleFocusMode,
                                    onOpenMarkdownGrid,
                                    onOpenExcelGrid,
                                    tool,
                                    setTool,
                                }) {
    const [loginOpen, setLoginOpen] = useState(false);
    const [subscriptionOpen, setSubscriptionOpen] = useState(false);
    const [profileOpen, setProfileOpen] = useState(false);
    const [saveOpen, setSaveOpen] = useState(false);
    const [exportOpen, setExportOpen] = useState(false);
    const [importOpen, setImportOpen] = useState(false);
    const [gridOpen, setGridOpen] = useState(false);
    const [fileOpen, setFileOpen] = useState(false);
    const [fileMenuPosition, setFileMenuPosition] = useState({ top: 70, left: 16 });
    const [newOpen, setNewOpen] = useState(false);
    const [newMenuPosition, setNewMenuPosition] = useState({ top: 70, left: 88 });
    const [videoGapSeconds, setVideoGapSeconds] = useState("0");
    const [videoPreAnimationDelaySeconds, setVideoPreAnimationDelaySeconds] = useState("0");
    const [trimVideoTrailingPause, setTrimVideoTrailingPause] = useState(true);
    const [videoFrameFrom, setVideoFrameFrom] = useState("1");
    const [videoFrameTo, setVideoFrameTo] = useState("1");
    const [videoExportMode, setVideoExportMode] = useState(() => localStorage.getItem("sketchydraw.videoExportMode") || "server");
    const [videoExportState, setVideoExportState] = useState({ exporting: false, progress: 0, status: "" });
    const [legalOpen, setLegalOpen] = useState(false);
    const [saveStatus, setSaveStatus] = useState({ state: "idle", message: "" });

    const currentExportZoom = Math.round(Number(exportZoomPercent) || 100);
    const exportZoomChoices = [...new Set([...ANIMATION_EXPORT_ZOOM_OPTIONS, currentExportZoom])]
        .sort((a, b) => a - b);
    const changeExportZoom = (value) => {
        onExportFitContentChange?.(false);
        onExportZoomPercentChange?.(Number(value));
    };
    const fitExportContent = () => {
        const outputSize = resolveAnimationExportSize(exportResolution, canvasSize);
        const fittedZoom = getAnimationExportFitZoomPercent({
            frames: timelineFrames,
            sourceSize: canvasSize,
            outputSize,
        });
        onExportFitContentChange?.(true);
        onExportZoomPercentChange?.(fittedZoom);
        onExportCameraPanChange?.({ x: 0, y: 0 });
    };

    const [user, setUser] = useState(getUser());
    const [loggedIn, setLoggedIn] = useState(isLoggedIn());
    const [announcement, setAnnouncement] = useState("");

    const [subscriptionStatus, setSubscriptionStatus] = useState(null);

    const [profileModalOpen, setProfileModalOpen] = useState(false);
    const [paymentsModalOpen, setPaymentsModalOpen] = useState(false);

    const [paymentRows, setPaymentRows] = useState([]);
    const [paymentLoading, setPaymentLoading] = useState(false);

    const [profileName, setProfileName] = useState(getUser()?.fullName || "");
    const [profileMessage, setProfileMessage] = useState("");

    const proUser = isProUser(user);

    // Create React App exposes browser environment variables only when
    // their names start with REACT_APP_. The value is read at build time.
    const showVideo =
        String(process.env.REACT_APP_SHOW_VIDEO || "")
            .trim()
            .toLowerCase() === "true";

    const selectCreatorPreset = (presetId) => {
        const nextPreset = presetId || null;

        // Free users can use WhatsApp Status creator mode only.
        if (!proUser && nextPreset && nextPreset !== "status") {
            const preset = SOCIAL_MEDIA_PRESETS[nextPreset];
            requestProUpgrade(`${preset?.shortLabel || "This"} creator mode`);
            return;
        }

        setSocialCreatorPreset?.(nextPreset);
    };

    const profileRef = useRef(null);
    const saveRef = useRef(null);
    const exportRef = useRef(null);
    const importRef = useRef(null);
    const gridRef = useRef(null);
    const legalRef = useRef(null);
    const fileRef = useRef(null);
    const fileTriggerRef = useRef(null);
    const filePortalRef = useRef(null);
    const newRef = useRef(null);
    const newTriggerRef = useRef(null);
    const newPortalRef = useRef(null);

    useEffect(() => {
        const totalFrames = Math.max(1, timelineFrames.length || 1);
        setVideoFrameFrom((current) => {
            const parsed = Number.parseInt(current, 10);
            return String(Number.isFinite(parsed) ? Math.min(Math.max(parsed, 1), totalFrames) : 1);
        });
        setVideoFrameTo((current) => {
            const parsed = Number.parseInt(current, 10);
            if (!Number.isFinite(parsed) || parsed <= 1) return String(totalFrames);
            return String(Math.min(Math.max(parsed, 1), totalFrames));
        });
    }, [timelineFrames.length]);


    useEffect(() => {
        const handleSaveStatus = (event) => {
            setSaveStatus(event.detail || { state: "idle", message: "" });
        };
        window.addEventListener("sketchydraw:save-status", handleSaveStatus);
        return () => window.removeEventListener("sketchydraw:save-status", handleSaveStatus);
    }, []);

    useEffect(() => {
        const handleVideoExportState = (event) => {
            setVideoExportState(event.detail || { exporting: false, progress: 0, status: "" });
        };
        window.addEventListener("sketchydraw:video-export-state", handleVideoExportState);
        return () => window.removeEventListener("sketchydraw:video-export-state", handleVideoExportState);
    }, []);

    useEffect(() => {
        const openSubscription = () => setSubscriptionOpen(true);
        window.addEventListener("sketchydraw:open-subscription", openSubscription);
        return () => window.removeEventListener("sketchydraw:open-subscription", openSubscription);
    }, []);

    const runProOnly = (feature, action) => {
        if (!proUser) {
            requestProUpgrade(feature);
            return;
        }
        action?.();
    };

    const chooseToolbarTool = (item) => {
        if (item.premium && !proUser) {
            requestProUpgrade(`${item.label} tool`);
            return;
        }
        setTool?.(item.id);
    };

    const openSidebarSection = (section) => {
        window.dispatchEvent(new CustomEvent("sketchydraw:open-sidebar-section", {
            detail: { section },
        }));
    };

    useEffect(() => {
        refreshAuthState();
    }, [loginOpen]);

    useEffect(() => {
        loadAnnouncement();

        const intervalId = setInterval(() => {
            loadAnnouncement();
        }, 3 * 60 * 1000);

        return () => clearInterval(intervalId);
    }, []);

    useEffect(() => {
        if (!loggedIn) {
            setSubscriptionStatus(null);
            return;
        }

        refreshSubscriptionStatus();

        const onUpdated = () => refreshSubscriptionStatus();
        window.addEventListener("sketchydraw:subscription-updated", onUpdated);

        return () => {
            window.removeEventListener("sketchydraw:subscription-updated", onUpdated);
        };
    }, [loggedIn]);

    useEffect(() => {
        const handleClickOutside = (e) => {
            if (profileRef.current && !profileRef.current.contains(e.target)) {
                setProfileOpen(false);
            }


            if (saveRef.current && !saveRef.current.contains(e.target)) {
                setSaveOpen(false);
            }

            if (exportRef.current && !exportRef.current.contains(e.target)) {
                setExportOpen(false);
            }

            if (importRef.current && !importRef.current.contains(e.target)) {
                setImportOpen(false);
            }

            if (gridRef.current && !gridRef.current.contains(e.target)) {
                setGridOpen(false);
            }

            if (legalRef.current && !legalRef.current.contains(e.target)) {
                setLegalOpen(false);
            }

            const clickedFileTrigger = fileRef.current?.contains(e.target);
            const clickedFilePortal = filePortalRef.current?.contains(e.target);
            if (!clickedFileTrigger && !clickedFilePortal) {
                setFileOpen(false);
            }

            const clickedNewTrigger = newRef.current?.contains(e.target);
            const clickedNewPortal = newPortalRef.current?.contains(e.target);
            if (!clickedNewTrigger && !clickedNewPortal) {
                setNewOpen(false);
            }
        };

        document.addEventListener("mousedown", handleClickOutside);

        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, []);

    useEffect(() => {
        const openSubscription = () => {
            setSubscriptionOpen(true);
            setProfileOpen(false);
            setSaveOpen(false);
            setExportOpen(false);
            setImportOpen(false);
            setGridOpen(false);
            setLegalOpen(false);
        };

        const openLogin = () => {
            setLoginOpen(true);
            setProfileOpen(false);
            setSaveOpen(false);
            setExportOpen(false);
            setImportOpen(false);
            setGridOpen(false);
            setLegalOpen(false);
        };

        window.addEventListener("sketchydraw:open-subscription", openSubscription);
        window.addEventListener("sketchydraw:open-login", openLogin);

        return () => {
            window.removeEventListener("sketchydraw:open-subscription", openSubscription);
            window.removeEventListener("sketchydraw:open-login", openLogin);
        };
    }, []);

    const refreshAuthState = () => {
        const nextUser = getUser();

        setUser(nextUser);
        setLoggedIn(isLoggedIn());
        setProfileName(nextUser?.fullName || "");
    };

    const refreshSubscriptionStatus = async () => {
        if (!isLoggedIn()) return null;

        try {
            const status = await getSubscriptionStatus();
            const updatedUser = mergeSubscriptionIntoUser(status);

            setSubscriptionStatus(status);

            if (updatedUser) {
                setUser(updatedUser);
                setProfileName(updatedUser.fullName || "");
            }

            return status;
        } catch (error) {
            console.error("Unable to load subscription status", error);
            return null;
        }
    };

    const loadAnnouncement = async () => {
        try {
            const data = await getActiveAnnouncement();

            if (data?.enabled && data?.message) {
                setAnnouncement(data.message);
            } else {
                setAnnouncement("");
            }
        } catch {
            setAnnouncement("");
        }
    };

    const openProfileModal = async () => {
        setProfileOpen(false);
        setProfileMessage("");
        setProfileModalOpen(true);

        try {
            const data = await getMyProfile();
            const updated = updateLocalUserProfile(data);

            setUser(updated);
            setProfileName(updated?.fullName || "");
        } catch (error) {
            console.error("Unable to load profile", error);
        }
    };

    const saveProfileName = async (event) => {
        event.preventDefault();
        setProfileMessage("Saving profile...");

        try {
            const data = await updateMyProfile({
                fullName: profileName,
            });

            const updated = updateLocalUserProfile(data);

            setUser(updated);
            setProfileName(updated?.fullName || "");
            setProfileMessage("Profile updated successfully.");
        } catch (error) {
            setProfileMessage(error?.message || "Unable to update profile.");
        }
    };

    const openPaymentHistory = async () => {
        setProfileOpen(false);
        setPaymentsModalOpen(true);
        setPaymentLoading(true);

        try {
            const rows = await getPaymentHistory();

            const allRows = Array.isArray(rows)
                ? rows
                : rows?.data || rows?.payments || rows?.content || [];

            const successRows = allRows.filter(
                (row) => String(row.status || "").toUpperCase() === "SUCCESS"
            );

            setPaymentRows(successRows);
        } catch (error) {
            console.error("Unable to load payment history", error);
            setPaymentRows([]);
        } finally {
            setPaymentLoading(false);
        }
    };

    const handleLogout = () => {
        logout();
        setUser(null);
        setLoggedIn(false);
        setSubscriptionStatus(null);
        setProfileOpen(false);
    };

    const goToLegalPage = (path) => {
        window.location.href = path;
    };

    const triggerSaveExisting = () => {
        window.dispatchEvent(
            new CustomEvent("sketchydraw:save-drawing", {
                detail: { saveAsNew: false },
            })
        );

        setSaveOpen(false);
    };

    const triggerSaveAsNew = () => {
        window.dispatchEvent(
            new CustomEvent("sketchydraw:save-drawing", {
                detail: { saveAsNew: true },
            })
        );

        setSaveOpen(false);
    };

    const triggerMyDrawings = () => {
        window.dispatchEvent(new Event("sketchydraw:open-my-drawings"));
        setProfileOpen(false);
    };

    const runExport = (fn) => {
        fn?.();
        setExportOpen(false);
    };

    const runVideoExport = () => {
        if (videoExportState.exporting) {
            alert(`Video export is already running: ${videoExportState.status || "Please wait"}`);
            return;
        }

        const totalFrames = timelineFrames.length;
        if (!totalFrames) {
            alert("There are no timeline frames to export.");
            return;
        }

        const requestedFrom = Number.parseInt(videoFrameFrom, 10);
        const requestedTo = Number.parseInt(videoFrameTo, 10);
        const frameFrom = Math.min(Math.max(Number.isFinite(requestedFrom) ? requestedFrom : 1, 1), totalFrames);
        const frameTo = Math.min(Math.max(Number.isFinite(requestedTo) ? requestedTo : totalFrames, 1), totalFrames);

        if (frameFrom > frameTo) {
            alert(`Start frame (${frameFrom}) cannot be after end frame (${frameTo}).`);
            return;
        }

        const requestedGapSeconds = Number(videoGapSeconds);
        const gapSeconds = Math.max(
            0,
            Math.min(120, Number.isFinite(requestedGapSeconds) ? requestedGapSeconds : 0)
        );
        const requestedPreAnimationDelaySeconds = Number(videoPreAnimationDelaySeconds);
        const preAnimationDelaySeconds = Math.max(
            0,
            Math.min(120, Number.isFinite(requestedPreAnimationDelaySeconds)
                ? requestedPreAnimationDelaySeconds
                : 0)
        );
        const exportScale = Math.max(1, Math.min(2, Number(exportZoomPercent) / 100));
        const backendSpeed = Math.max(0.1, Math.min(4, Number(videoBackendSpeed) || 1));
        const selectedFrames = timelineFrames.slice(frameFrom - 1, frameTo);
        const paddedFrom = String(frameFrom).padStart(2, "0");
        const paddedTo = String(frameTo).padStart(2, "0");

        window.dispatchEvent(
            new CustomEvent("sketchydraw:export-video", {
                detail: {
                    gapSeconds,
                    preAnimationDelaySeconds,
                    playbackSpeed,
                    ffmpegSpeed: backendSpeed,
                    exportScale,
                    resolution: exportResolution,
                    zoomPercent: exportZoomPercent,
                    fitContent: exportFitContent,
                    pan: exportCameraPan,
                    textScalePercent: exportTextScalePercent,
                    trimTrailingPause: trimVideoTrailingPause,
                    timelineFrames: JSON.parse(JSON.stringify(selectedFrames)),
                    mode: videoExportMode,
                    frameFrom,
                    frameTo,
                    totalFrames,
                    fileName: `sketchydraw-frames-${paddedFrom}-${paddedTo}.${videoExportMode === "server" ? "mp4" : "webm"}`,
                },
            })
        );

        setExportOpen(false);
    };

    const applyCanvasPattern = (pattern) => {
        if (pattern === "notebook") {
            updateCanvasProps?.({
                pattern: "notebook",
                pageMode: true,
                pageCount: canvasProps?.pageCount || DEFAULT_NOTEBOOK_PAGE_COUNT,
            });

            setShowGrid?.(false);
            setGridOpen(false);
            return;
        }

        updateCanvasProps?.({
            pattern,
            pageMode: false,
        });

        setShowGrid?.(pattern === "grid");
        setGridOpen(false);
    };
    const addNotebookPage = () => {
        const currentPageCount = Number(
            canvasProps?.pageCount || DEFAULT_NOTEBOOK_PAGE_COUNT
        );

        const nextPageCount = Math.min(
            MAX_NOTEBOOK_PAGE_COUNT,
            Math.max(DEFAULT_NOTEBOOK_PAGE_COUNT, currentPageCount + 1)
        );

        updateCanvasProps?.({
            pattern: "notebook",
            pageMode: true,
            pageCount: nextPageCount,
            pageViewMode: "single",
            currentPageIndex: nextPageCount - 1,
        });

        setShowGrid?.(false);

        window.dispatchEvent(
            new CustomEvent("sketchydraw:notebook-page-added", {
                detail: {
                    pageIndex: nextPageCount - 1,
                },
            })
        );
    };

    const removeNotebookPage = () => {
        const currentPageCount = Number(
            canvasProps?.pageCount || DEFAULT_NOTEBOOK_PAGE_COUNT
        );
        const nextPageCount = Math.max(
            DEFAULT_NOTEBOOK_PAGE_COUNT,
            currentPageCount - 1
        );
        const currentPageIndex = Math.max(
            0,
            Math.min(
                nextPageCount - 1,
                Number(canvasProps?.currentPageIndex || 0)
            )
        );

        updateCanvasProps?.({
            pattern: "notebook",
            pageMode: true,
            pageCount: nextPageCount,
            currentPageIndex,
        });

        setShowGrid?.(false);

        window.dispatchEvent(
            new CustomEvent("sketchydraw:notebook-page-focus", {
                detail: {
                    pageIndex: currentPageIndex,
                    direction: "prev",
                    zoom: 1,
                },
            })
        );
    };

    const activePattern = canvasProps?.pattern || (showGrid ? "grid" : "blank");

    const currentGridLabel =
        activePattern === "notebook"
            ? "Notebook"
            : activePattern === "dots"
                ? "Dot Grid"
                : activePattern === "blocks"
                    ? "Blocks"
                    : activePattern === "grid"
                        ? "Grid Lines"
                        : "Blank";

    const getExpiryDate = () => {
        return (
            user?.subscription?.endsAt ||
            subscriptionStatus?.endsAt ||
            subscriptionStatus?.endDate ||
            subscriptionStatus?.validTill ||
            null
        );
    };

    const expiryDate = getExpiryDate();

    return (
        <>
            <div className="legal-floating-menu-wrap" ref={legalRef}>
                <button
                    type="button"
                    className="legal-floating-burger"
                    onClick={() => setLegalOpen((v) => !v)}
                    title="Menu"
                >
                    ☰
                </button>

                {legalOpen && (
                    <div className="legal-floating-menu">
                        <div className="legal-menu-brand">
                            <strong>SketchyDraw</strong>
                            <span>Legal & support</span>
                        </div>

                        <button type="button" onClick={() => goToLegalPage("/terms")}>
                            Terms and Conditions
                        </button>

                        <button type="button" onClick={() => goToLegalPage("/privacy-policy")}>
                            Privacy Policy
                        </button>

                        <button type="button" onClick={() => goToLegalPage("/refund-policy")}>
                            Refund Policy
                        </button>

                        <button type="button" onClick={() => goToLegalPage("/cancellation-policy")}>
                            Cancellation Policy
                        </button>

                        <button type="button" onClick={() => goToLegalPage("/delivery-policy")}>
                            Delivery Policy
                        </button>

                        <button type="button" onClick={() => goToLegalPage("/contact-us")}>
                            Contact Us
                        </button>
                    </div>
                )}
            </div>

            <div className="topbar">
                <div className="topbar-command-row">
                    <div className="topbar-actions">
                        {saveStatus.message && (
                            <div className={`toolbar-save-status ${saveStatus.state}`} title={saveStatus.message}>
                                <span aria-hidden="true">{saveStatus.state === "saving" ? "↻" : "✓"}</span>
                                <span>{saveStatus.state === "saved" ? "Auto-saved" : saveStatus.message}</span>
                            </div>
                        )}
                        <button type="button" onClick={undo} disabled={!canUndo} title="Undo last action">
                            Undo
                        </button>

                        <button type="button" onClick={redo} disabled={!canRedo} title="Redo last action">
                            Redo
                        </button>

                        <button type="button" onClick={clearCanvas} className="toolbar-clear-action" title="Clear current canvas">
                            Clear
                        </button>

                        <div className="file-native-menu-wrap toolbar-document-control" ref={fileRef}>
                            <button
                                ref={fileTriggerRef}
                                type="button"
                                className="native-menu-trigger"
                                onClick={() => {
                                    const rect = fileTriggerRef.current?.getBoundingClientRect();
                                    if (rect) setFileMenuPosition({ top: rect.bottom + 8, left: rect.left });
                                    setFileOpen((value) => !value);
                                    setNewOpen(false);
                                }}
                            >
                                File <span>⌄</span>
                            </button>

                            {fileOpen && createPortal(
                                <div
                                    ref={filePortalRef}
                                    className="native-file-menu native-menu-portal"
                                    style={{ top: fileMenuPosition.top, left: fileMenuPosition.left }}
                                >
                                    <button type="button" onClick={() => { createNewDrawing?.(); setFileOpen(false); }}>
                                        <span>New drawing</span><kbd>⌘N</kbd>
                                    </button>
                                    <div className="native-menu-divider" />

                                    <button type="button" onClick={() => { window.dispatchEvent(new Event("sketchydraw:open-my-drawings")); setFileOpen(false); }}>
                                        <span>Open drawing…</span><kbd>⌘O</kbd>
                                    </button>

                                    <div className="native-menu-divider" />

                                    <button
                                        type="button"
                                        onClick={() => {
                                            triggerSaveExisting();
                                            setFileOpen(false);
                                        }}
                                    >
                                        <span>Save</span>
                                        <kbd>⌘S</kbd>
                                    </button>

                                    <button
                                        type="button"
                                        onClick={() => {
                                            triggerSaveAsNew();
                                            setFileOpen(false);
                                        }}
                                    >
                                        <span>Save As…</span>
                                        <kbd>⇧⌘S</kbd>
                                    </button>

                                    <div className="native-menu-divider" />

                                    <div className="native-submenu-row">
                                        <button type="button"><span>Import</span><span className="submenu-arrow">›</span></button>
                                        <div className="native-submenu native-import-submenu">
                                            <button type="button" onClick={() => { (openImportPicker || openJsonPicker)?.("json"); setFileOpen(false); }}>JSON…</button>
                                            <button type="button" onClick={() => { openImportPicker?.("ppt"); setFileOpen(false); }}>PowerPoint…</button>
                                            <button type="button" onClick={() => { openImportPicker?.("word"); setFileOpen(false); }}>Word…</button>
                                            <button type="button" onClick={() => { openImportPicker?.("excel"); setFileOpen(false); }}>Excel / CSV…</button>
                                            <button type="button" onClick={() => { openImportPicker?.("protected"); setFileOpen(false); }}>Protected drawing…</button>
                                        </div>
                                    </div>

                                    <div className="native-submenu-row">
                                        <button type="button"><span>Export</span><span className="submenu-arrow">›</span></button>
                                        <div className="native-submenu native-export-submenu">
                                            <button type="button" onClick={() => { runExport(exportPNG); setFileOpen(false); }}>PNG…</button>
                                            <button type="button" onClick={() => { runExport(exportJPEG); setFileOpen(false); }}>JPEG…</button>
                                            <button type="button" onClick={() => { runExport(exportSVG); setFileOpen(false); }}>SVG…</button>
                                            <button type="button" onClick={() => { runExport(exportPDF); setFileOpen(false); }}>PDF…</button>
                                            <button type="button" onClick={() => { runExport(exportJSON); setFileOpen(false); }}>JSON…</button>
                                            <button type="button" onClick={() => { runExport(exportProtectedDrawing); setFileOpen(false); }}>Password-protected…</button>
                                            <div className="native-menu-divider" />
                                            <button type="button" onClick={() => { runProOnly("PowerPoint export", () => runExport(exportPPT)); setFileOpen(false); }}>PowerPoint… <span className="native-pro-badge">PRO</span></button>
                                            <button type="button" onClick={() => { runProOnly("Excel export", () => runExport(exportExcel)); setFileOpen(false); }}>Excel… <span className="native-pro-badge">PRO</span></button>
                                            <button type="button" onClick={() => { runProOnly("CSV export", () => runExport(exportCSV)); setFileOpen(false); }}>CSV… <span className="native-pro-badge">PRO</span></button>
                                            <div className="native-menu-divider" />
                                            <button type="button" onClick={() => { runExport(() => exportInstagram?.("post")); setFileOpen(false); }}>Instagram Post…</button>
                                            <button type="button" onClick={() => { runExport(() => exportInstagram?.("portrait")); setFileOpen(false); }}>Instagram Portrait…</button>
                                            <button type="button" onClick={() => { runExport(() => exportInstagram?.("story")); setFileOpen(false); }}>Instagram Story…</button>
                                            <button type="button" onClick={() => { runExport(() => exportInstagram?.("status")); setFileOpen(false); }}>WhatsApp Status…</button>
                                            <div className="native-menu-divider" />
                                            <button type="button" onClick={() => { runProOnly("GIF export", () => runExport(() => exportGIF?.({ resolution: exportResolution, zoomPercent: exportZoomPercent, fitContent: exportFitContent, pan: exportCameraPan, textScalePercent: exportTextScalePercent }))); setFileOpen(false); }}>GIF… <span className="native-pro-badge">PRO</span></button>
                                            <button type="button" onClick={() => { runProOnly("Current frame GIF export", () => runExport(() => exportGIF?.({ currentFrameOnly: true, resolution: exportResolution, zoomPercent: exportZoomPercent, fitContent: exportFitContent, pan: exportCameraPan, textScalePercent: exportTextScalePercent }))); setFileOpen(false); }}>Current frame GIF… <span className="native-pro-badge">PRO</span></button>

                                            {showVideo && (
                                                <>
                                                    <div className="native-menu-divider" />

                                                    {proUser ? (
                                                        <details className="native-video-export">
                                                            <summary>
                                                                <span>Export video…</span>
                                                                <span className="native-pro-badge">PRO</span>
                                                            </summary>

                                                            <div className="native-video-export-panel">
                                                                <label>
                                                                    <span>UI / preview speed</span>
                                                                    <input
                                                                        type="number"
                                                                        min="0.1"
                                                                        max="4"
                                                                        step="0.05"
                                                                        value={playbackSpeed}
                                                                        onFocus={(event) => event.target.select()}
                                                                        onChange={(event) => {
                                                                            if (event.target.value === "") return;
                                                                            const value = Number(event.target.value);
                                                                            if (Number.isFinite(value) && value > 0) onPlaybackSpeedChange?.(value);
                                                                        }}
                                                                        disabled={videoExportState.exporting}
                                                                        title="Custom UI animation speed, from 0.1× to 4×"
                                                                    />
                                                                </label>

                                                                <label>
                                                                    <span>Backend speed (FFmpeg)</span>
                                                                    <input
                                                                        type="number"
                                                                        min="0.1"
                                                                        max="4"
                                                                        step="0.05"
                                                                        value={videoBackendSpeed}
                                                                        onFocus={(event) => event.target.select()}
                                                                        onChange={(event) => {
                                                                            const value = Number(event.target.value);
                                                                            if (Number.isFinite(value)) onVideoBackendSpeedChange?.(value)
                                                                        }}
                                                                        disabled={videoExportState.exporting || videoExportMode !== "server"}
                                                                    />
                                                                    <small>Final MP4 only · custom 0.1×–4× · 1× normal</small>
                                                                </label>

                                                                <label>
                                                                    <span>Delay before animation</span>
                                                                    <input
                                                                        type="number"
                                                                        min="0"
                                                                        max="120"
                                                                        step="0.5"
                                                                        value={videoPreAnimationDelaySeconds}
                                                                        onChange={(event) =>
                                                                            setVideoPreAnimationDelaySeconds(event.target.value)
                                                                        }
                                                                        disabled={videoExportState.exporting}
                                                                    />
                                                                </label>

                                                                <label>
                                                                    <span>Hold after each frame</span>
                                                                    <input
                                                                        type="number"
                                                                        min="0"
                                                                        max="120"
                                                                        step="0.5"
                                                                        value={videoGapSeconds}
                                                                        onChange={(event) =>
                                                                            setVideoGapSeconds(event.target.value)
                                                                        }
                                                                        disabled={videoExportState.exporting}
                                                                    />
                                                                </label>

                                                                <label>
                                                                    <span>Resolution</span>
                                                                    <select
                                                                        value={exportResolution}
                                                                        onChange={(event) => onExportResolutionChange?.(event.target.value)}
                                                                        disabled={videoExportState.exporting}
                                                                    >
                                                                        {ANIMATION_EXPORT_RESOLUTION_OPTIONS.map((option) => (
                                                                            <option key={option.value} value={option.value}>{option.label}</option>
                                                                        ))}
                                                                    </select>
                                                                </label>

                                                                <label>
                                                                    <span>HD camera zoom</span>
                                                                    <select
                                                                        value={exportZoomPercent}
                                                                        onChange={(event) => changeExportZoom(event.target.value)}
                                                                        disabled={videoExportState.exporting}
                                                                    >
                                                                        {exportZoomChoices.map((zoom) => (
                                                                            <option key={zoom} value={zoom}>{zoom}%{zoom === 150 ? " · Recommended" : ""}</option>
                                                                        ))}
                                                                    </select>
                                                                </label>

                                                                <label>
                                                                    <span>Remove trailing dead air</span>
                                                                    <input
                                                                        type="checkbox"
                                                                        checked={trimVideoTrailingPause}
                                                                        onChange={(event) =>
                                                                            setTrimVideoTrailingPause(event.target.checked)
                                                                        }
                                                                        disabled={videoExportState.exporting}
                                                                    />
                                                                </label>

                                                                <div className="native-video-frame-range">
                                                                    <label>
                                                                        <span>From frame</span>
                                                                        <input
                                                                            type="number"
                                                                            min="1"
                                                                            max={Math.max(1, timelineFrames.length)}
                                                                            step="1"
                                                                            value={videoFrameFrom}
                                                                            onChange={(event) =>
                                                                                setVideoFrameFrom(event.target.value)
                                                                            }
                                                                            disabled={
                                                                                videoExportState.exporting ||
                                                                                timelineFrames.length === 0
                                                                            }
                                                                        />
                                                                    </label>

                                                                    <label>
                                                                        <span>To frame</span>
                                                                        <input
                                                                            type="number"
                                                                            min="1"
                                                                            max={Math.max(1, timelineFrames.length)}
                                                                            step="1"
                                                                            value={videoFrameTo}
                                                                            onChange={(event) =>
                                                                                setVideoFrameTo(event.target.value)
                                                                            }
                                                                            disabled={
                                                                                videoExportState.exporting ||
                                                                                timelineFrames.length === 0
                                                                            }
                                                                        />
                                                                    </label>
                                                                </div>

                                                                <div className="native-video-range-hint">
                                                                    {timelineFrames.length > 0
                                                                        ? `Frames ${videoFrameFrom}–${videoFrameTo} of ${timelineFrames.length}`
                                                                        : "No frames available"}
                                                                </div>

                                                                <label>
                                                                    <span>Export using</span>
                                                                    <select
                                                                        value={videoExportMode}
                                                                        onChange={(event) => {
                                                                            const mode = event.target.value;
                                                                            setVideoExportMode(mode);
                                                                            localStorage.setItem(
                                                                                "sketchydraw.videoExportMode",
                                                                                mode
                                                                            );
                                                                        }}
                                                                        disabled={videoExportState.exporting}
                                                                    >
                                                                        <option value="server">
                                                                            Server MP4 (recommended)
                                                                        </option>
                                                                        <option value="browser">
                                                                            Browser WebM
                                                                        </option>
                                                                    </select>
                                                                </label>

                                                                <button
                                                                    type="button"
                                                                    className="native-video-export-button"
                                                                    onClick={() =>
                                                                        runProOnly("Video export", runVideoExport)
                                                                    }
                                                                    disabled={
                                                                        videoExportState.exporting ||
                                                                        timelineFrames.length === 0
                                                                    }
                                                                >
                                                                    {videoExportState.exporting
                                                                        ? `Exporting ${Math.round(
                                                                            videoExportState.progress || 0
                                                                        )}%`
                                                                        : videoExportMode === "server"
                                                                            ? "Export MP4"
                                                                            : "Export WebM"}
                                                                </button>

                                                                {videoExportState.exporting && (
                                                                    <div
                                                                        className="native-video-progress"
                                                                        role="status"
                                                                        aria-live="polite"
                                                                    >
                                                                        <progress
                                                                            max="100"
                                                                            value={Math.round(
                                                                                videoExportState.progress || 0
                                                                            )}
                                                                        />
                                                                        <span>
                                                                        {videoExportState.status ||
                                                                            "Exporting video…"}
                                                                    </span>
                                                                    </div>
                                                                )}
                                                            </div>
                                                        </details>
                                                    ) : (
                                                        <button
                                                            type="button"
                                                            onClick={() => {
                                                                requestProUpgrade("Video export");
                                                                setFileOpen(false);
                                                            }}
                                                        >
                                                            <span>Export video…</span>
                                                            <span className="native-pro-badge">PRO</span>
                                                        </button>
                                                    )}
                                                </>
                                            )}
                                        </div>
                                    </div>

                                    <div className="native-menu-divider" />
                                    <button type="button" onClick={() => { runExport(printCanvas); setFileOpen(false); }}>
                                        <span>Print…</span><kbd>⌘P</kbd>
                                    </button>
                                </div>,
                                document.body
                            )}
                        </div>

                        <div className="new-native-menu-wrap toolbar-document-control" ref={newRef}>
                            <button
                                ref={newTriggerRef}
                                type="button"
                                className="native-menu-trigger native-new-trigger"
                                onClick={() => {
                                    const rect = newTriggerRef.current?.getBoundingClientRect();
                                    if (rect) setNewMenuPosition({ top: rect.bottom + 8, left: rect.left });
                                    setNewOpen((value) => !value);
                                    setFileOpen(false);
                                }}
                            >
                                New <span>⌄</span>
                            </button>
                            {newOpen && createPortal(
                                <div
                                    ref={newPortalRef}
                                    className="native-file-menu native-new-menu native-menu-portal"
                                    style={{ top: newMenuPosition.top, left: newMenuPosition.left }}
                                >
                                    <button type="button" onClick={() => { createNewDrawing?.(); setNewOpen(false); }}>New drawing</button>
                                    <div className="native-menu-divider" />
                                    <button type="button" onClick={() => { applyCanvasPattern("blank"); setNewOpen(false); }}>Blank canvas</button>
                                    <button type="button" onClick={() => { applyCanvasPattern("grid"); setNewOpen(false); }}>Grid canvas</button>
                                    <button type="button" onClick={() => { applyCanvasPattern("notebook"); setNewOpen(false); }}>Notebook</button>
                                    <button type="button" onClick={() => { applyCanvasPattern("dots"); setNewOpen(false); }}>Dot grid</button>
                                    <button type="button" onClick={() => { applyCanvasPattern("blocks"); setNewOpen(false); }}>Blocks</button>
                                    <button type="button" onClick={() => { onOpenExcelGrid?.(); setNewOpen(false); }}>New Excel</button>
                                    <button type="button" onClick={() => { onOpenMarkdownGrid?.(); setNewOpen(false); }}>New Markdown</button>
                                    <div className="native-menu-divider" />
                                    <button type="button" onClick={() => { selectCreatorPreset(null); setNewOpen(false); }}>Free canvas</button>
                                    <button type="button" onClick={() => { selectCreatorPreset("post"); setNewOpen(false); }}>Instagram Post{!proUser ? " · PRO" : ""}</button>
                                    <button type="button" onClick={() => { selectCreatorPreset("portrait"); setNewOpen(false); }}>Instagram Portrait{!proUser ? " · PRO" : ""}</button>
                                    <button type="button" onClick={() => { selectCreatorPreset("story"); setNewOpen(false); }}>Instagram Story{!proUser ? " · PRO" : ""}</button>
                                    <button type="button" onClick={() => { selectCreatorPreset("status"); setNewOpen(false); }}>WhatsApp Status · FREE</button>
                                </div>,
                                document.body
                            )}
                        </div>

                        <div className={`creator-toolbar-control toolbar-creator-control ${socialCreatorPreset ? "active" : ""}`}>
                            <span className="creator-toolbar-icon" aria-hidden="true">✦</span>
                            <select
                                value={socialCreatorPreset || ""}
                                onChange={(event) => selectCreatorPreset(event.target.value)}
                                title="Choose a creator canvas size"
                                aria-label="Creator mode"
                            >
                                <option value="">Creator mode</option>
                                {Object.values(SOCIAL_MEDIA_PRESETS).map((preset) => (
                                    <option key={preset.id} value={preset.id}>
                                        {preset.shortLabel} · {preset.width}×{preset.height}{!proUser && preset.id !== "status" ? " · PRO" : preset.id === "status" ? " · FREE" : ""}
                                    </option>
                                ))}
                            </select>
                        </div>

                        <button
                            type="button"
                            className="toolbar-focus-button toolbar-view-control"
                            onClick={onToggleFocusMode}
                            title="Open full-screen canvas"
                            aria-label="Open full-screen canvas"
                        >
                            <span aria-hidden="true">⛶</span>
                            <span>Full screen</span>
                        </button>

                        <div className="save-menu-wrap legacy-toolbar-menu" title="Save this drawing" ref={saveRef}>
                            <button
                                type="button"
                                className="toolbar-primary-action save-trigger-btn"
                                onClick={() => setSaveOpen((v) => !v)}
                                title="Save this drawing"
                            >
                                Save <span title="Save this drawing">⌄</span>
                            </button>

                            {saveOpen && (
                                <div className="save-dropdown">
                                    <button
                                        type="button"
                                        onClick={() => {
                                            createNewDrawing?.();
                                            setSaveOpen(false);
                                        }}
                                    >
                                        ✨ New Drawing
                                    </button>

                                    <button
                                        type="button"
                                        onClick={() => {
                                            triggerSaveExisting?.();
                                            setSaveOpen(false);
                                        }}
                                    >
                                        💾 Save
                                    </button>

                                    <button
                                        type="button"
                                        onClick={() => {
                                            triggerSaveAsNew?.();
                                            setSaveOpen(false);
                                        }}
                                    >
                                        🆕 Save As
                                    </button>

                                    <button
                                        type="button"
                                        onClick={() => {
                                            window.dispatchEvent(new Event("sketchydraw:open-my-drawings"));
                                            setSaveOpen(false);
                                        }}
                                    >
                                        📂 View Saved Drawings
                                    </button>
                                </div>
                            )}
                        </div>

                        <div className="export-menu-wrap legacy-toolbar-menu" ref={importRef}>
                            <button
                                type="button"
                                className="toolbar-dark-action export-trigger-btn"
                                onClick={() => setImportOpen((value) => !value)}
                                title="Import JSON, PowerPoint, or Excel"
                            >
                                Import <span>⌄</span>
                            </button>

                            {importOpen && (
                                <div className="export-dropdown">
                                    <button type="button" onClick={() => { (openImportPicker || openJsonPicker)?.("json"); setImportOpen(false); }}>
                                        📄 Import JSON
                                    </button>
                                    <button type="button" onClick={() => { openImportPicker?.("ppt"); setImportOpen(false); }}>
                                        📊 Import PowerPoint
                                    </button>
                                    <button type="button" onClick={() => { openImportPicker?.("word"); setImportOpen(false); }}>
                                        📝 Import Word
                                    </button>
                                    <button type="button" onClick={() => { openImportPicker?.("excel"); setImportOpen(false); }}>
                                        📈 Import Excel / CSV
                                    </button>
                                </div>
                            )}
                        </div>

                        <div className="social-creator-control legacy-toolbar-menu">
                            <span className="social-creator-label">Creator canvas</span>
                            <select
                                value={socialCreatorPreset || ""}
                                onChange={(event) => selectCreatorPreset(event.target.value)}
                                title="Show Instagram or WhatsApp composition guides"
                            >
                                <option value="">Off / Free canvas</option>
                                {Object.values(SOCIAL_MEDIA_PRESETS).map((preset) => (
                                    <option key={preset.id} value={preset.id}>
                                        {preset.shortLabel} · {preset.width}×{preset.height}{!proUser && preset.id !== "status" ? " · PRO" : preset.id === "status" ? " · FREE" : ""}
                                    </option>
                                ))}
                            </select>
                        </div>

                        <div className="export-menu-wrap legacy-toolbar-menu" ref={exportRef}>
                            <button
                                type="button"
                                className="toolbar-dark-action export-trigger-btn"
                                onClick={() => setExportOpen((v) => !v)}
                                title="Export this drawing"
                            >
                                Export <span>⌄</span>
                            </button>

                            {exportOpen && (
                                <div className="export-dropdown export-dropdown-wide">
                                    <div className="export-dropdown-section-title">Quick export</div>
                                    <button type="button" onClick={() => runExport(exportPNG)}>
                                        🖼️ Export as PNG
                                    </button>
                                    <button type="button" onClick={() => runExport(exportJPEG)}>
                                        🖼️ Export as JPEG
                                    </button>
                                    <button type="button" onClick={() => runExport(exportSVG)}>
                                        🧩 Export as SVG
                                    </button>
                                    <button type="button" onClick={() => runExport(exportPDF)}>
                                        📕 Export as PDF
                                    </button>
                                    <button type="button" className="export-print-btn" onClick={() => runExport(printCanvas)}>
                                        🖨️ Print Canvas
                                    </button>
                                    <button type="button" onClick={() => runExport(exportJSON)}>
                                        📄 Export as JSON
                                    </button>
                                    <button type="button" onClick={() => runProOnly("PowerPoint export", () => runExport(exportPPT))}>
                                        📊 Export as PowerPoint
                                    </button>
                                    <button type="button" onClick={() => runProOnly("Excel export", () => runExport(exportExcel))}>
                                        📗 Export as Excel
                                    </button>
                                    <button type="button" onClick={() => runProOnly("CSV export", () => runExport(exportCSV))}>
                                        🧾 Export as CSV
                                    </button>

                                    <div className="export-dropdown-divider" />
                                    <div className="export-dropdown-section-title">Social sizes</div>
                                    <button type="button" onClick={() => runExport(() => exportInstagram?.("portrait"))}>
                                        📱 Instagram Portrait (1080×1350)
                                    </button>
                                    <button type="button" onClick={() => runExport(() => exportInstagram?.("story"))}>
                                        📲 Instagram Story (1080×1920)
                                    </button>
                                    <button type="button" onClick={() => runExport(() => exportInstagram?.("status"))}>
                                        💬 WhatsApp Status (1080×1920)
                                    </button>
                                    <button type="button" onClick={() => runExport(() => exportInstagram?.("post"))}>
                                        ⬜ Instagram Post (1080×1080)
                                    </button>

                                    <div className="export-dropdown-divider" />
                                    <div className="export-dropdown-section-title">Animation</div>
                                    <label>
                                        Timeline speed
                                        <input
                                            type="number"
                                            min="0.1"
                                            max="4"
                                            step="0.05"
                                            value={playbackSpeed}
                                            onFocus={(event) => event.target.select()}
                                            onChange={(event) => {
                                                if (event.target.value === "") return;
                                                const value = Number(event.target.value);
                                                if (Number.isFinite(value) && value > 0) onPlaybackSpeedChange?.(value);
                                            }}
                                            disabled={gifExporting || videoExportState.exporting}
                                            title="Custom UI animation speed, from 0.1× to 4×"
                                        />
                                    </label>
                                    <label>
                                        Export resolution
                                        <select
                                            value={exportResolution}
                                            onChange={(event) => onExportResolutionChange?.(event.target.value)}
                                            disabled={gifExporting || videoExportState.exporting}
                                        >
                                            {ANIMATION_EXPORT_RESOLUTION_OPTIONS.map((option) => (
                                                <option key={option.value} value={option.value}>{option.label}</option>
                                            ))}
                                        </select>
                                    </label>
                                    <label>
                                        HD camera zoom
                                        <select
                                            value={exportZoomPercent}
                                            onChange={(event) => changeExportZoom(event.target.value)}
                                            disabled={gifExporting || videoExportState.exporting}
                                        >
                                            {exportZoomChoices.map((zoom) => (
                                                <option key={zoom} value={zoom}>{zoom}%{zoom === 150 ? " · Recommended" : ""}</option>
                                            ))}
                                        </select>
                                    </label>
                                    <label>
                                        Global text size
                                        <select
                                            value={exportTextScalePercent}
                                            onChange={(event) => onExportTextScalePercentChange?.(Number(event.target.value))}
                                            disabled={gifExporting || videoExportState.exporting}
                                        >
                                            {ANIMATION_EXPORT_TEXT_SCALE_OPTIONS.map((size) => (
                                                <option key={size} value={size}>{size}%{size === 125 ? " · Clear" : ""}</option>
                                            ))}
                                        </select>
                                    </label>
                                    <button
                                        type="button"
                                        onClick={fitExportContent}
                                        disabled={gifExporting || videoExportState.exporting}
                                    >
                                        ⛶ Fit content automatically
                                    </button>
                                    <button type="button" onClick={() => runProOnly("GIF export", () => runExport(() => exportGIF?.({ resolution: exportResolution, zoomPercent: exportZoomPercent, fitContent: exportFitContent, pan: exportCameraPan, textScalePercent: exportTextScalePercent })))} disabled={gifExporting}>
                                        🎞️ {gifExporting
                                        ? `Exporting GIF ${Math.round((gifExportProgress || 0) * 100)}%`
                                        : "Export all frames as GIF · PRO"}
                                    </button>
                                    <button type="button" onClick={() => runProOnly("Current frame GIF export", () => runExport(() => exportGIF?.({ currentFrameOnly: true, resolution: exportResolution, zoomPercent: exportZoomPercent, fitContent: exportFitContent, pan: exportCameraPan, textScalePercent: exportTextScalePercent })))} disabled={gifExporting}>
                                        🖼️ Export current frame GIF · PRO
                                    </button>

                                    {proUser ? (
                                        <details className="export-advanced-section">
                                            <summary>🎬 Export video <span className="pro-inline-badge">PRO</span></summary>
                                            <div className="export-video-box">
                                                <label>
                                                    Backend speed (FFmpeg)
                                                    <input
                                                        type="number"
                                                        min="0.1"
                                                        max="4"
                                                        step="0.05"
                                                        value={videoBackendSpeed}
                                                        onFocus={(event) => event.target.select()}
                                                        onChange={(event) => {
                                                            const value = Number(event.target.value);
                                                            if (Number.isFinite(value)) onVideoBackendSpeedChange?.(value)
                                                        }}
                                                        disabled={videoExportState.exporting || videoExportMode !== "server"}
                                                    />
                                                    <small>Final MP4: custom 0.1×–4× · 1× normal</small>
                                                </label>

                                                <label>
                                                    Delay before animation (seconds)
                                                    <input
                                                        type="number"
                                                        min="0"
                                                        max="120"
                                                        step="0.5"
                                                        value={videoPreAnimationDelaySeconds}
                                                        onChange={(event) => setVideoPreAnimationDelaySeconds(event.target.value)}
                                                    />
                                                </label>

                                                <label>
                                                    Hold after animation before next slide (seconds)
                                                    <input
                                                        type="number"
                                                        min="0"
                                                        max="120"
                                                        step="0.5"
                                                        value={videoGapSeconds}
                                                        onChange={(event) => setVideoGapSeconds(event.target.value)}
                                                    />
                                                </label>

                                                <label>
                                                    Resolution
                                                    <select
                                                        value={exportResolution}
                                                        onChange={(event) => onExportResolutionChange?.(event.target.value)}
                                                        disabled={videoExportState.exporting}
                                                    >
                                                        {ANIMATION_EXPORT_RESOLUTION_OPTIONS.map((option) => (
                                                            <option key={option.value} value={option.value}>{option.label}</option>
                                                        ))}
                                                    </select>
                                                </label>

                                                <label>
                                                    HD camera zoom
                                                    <select
                                                        value={exportZoomPercent}
                                                        onChange={(event) => changeExportZoom(event.target.value)}
                                                        disabled={videoExportState.exporting}
                                                    >
                                                        {exportZoomChoices.map((zoom) => (
                                                            <option key={zoom} value={zoom}>{zoom}%{zoom === 150 ? " · Recommended" : ""}</option>
                                                        ))}
                                                    </select>
                                                </label>

                                                <label>
                                                    Global text size
                                                    <select
                                                        value={exportTextScalePercent}
                                                        onChange={(event) => onExportTextScalePercentChange?.(Number(event.target.value))}
                                                        disabled={videoExportState.exporting}
                                                    >
                                                        {ANIMATION_EXPORT_TEXT_SCALE_OPTIONS.map((size) => (
                                                            <option key={size} value={size}>{size} %{size === 125 ? " · Clear" : ""}</option>
                                                        ))}
                                                    </select>
                                                </label>

                                                <button
                                                    type="button"
                                                    onClick={fitExportContent}
                                                    disabled={videoExportState.exporting}
                                                >
                                                    ⛶ Fit content automatically
                                                </button>

                                                <label>
                                                    <input
                                                        type="checkbox"
                                                        checked={trimVideoTrailingPause}
                                                        onChange={(event) => setTrimVideoTrailingPause(event.target.checked)}
                                                        disabled={videoExportState.exporting}
                                                    />
                                                    Remove trailing dead air
                                                </label>

                                                <div className="video-frame-range">
                                                    <label>
                                                        From frame
                                                        <input
                                                            type="number"
                                                            min="1"
                                                            max={Math.max(1, timelineFrames.length)}
                                                            step="1"
                                                            value={videoFrameFrom}
                                                            onChange={(event) => setVideoFrameFrom(event.target.value)}
                                                            disabled={videoExportState.exporting || timelineFrames.length === 0}
                                                        />
                                                    </label>

                                                    <label>
                                                        To frame
                                                        <input
                                                            type="number"
                                                            min="1"
                                                            max={Math.max(1, timelineFrames.length)}
                                                            step="1"
                                                            value={videoFrameTo}
                                                            onChange={(event) => setVideoFrameTo(event.target.value)}
                                                            disabled={videoExportState.exporting || timelineFrames.length === 0}
                                                        />
                                                    </label>
                                                </div>

                                                <div className="video-range-hint">
                                                    Exporting {Math.max(0, Math.min(timelineFrames.length, Number(videoFrameTo) || 0) - Math.max(1, Number(videoFrameFrom) || 1) + 1)} of {timelineFrames.length} frames
                                                </div>

                                                <label>
                                                    Export using
                                                    <select
                                                        value={videoExportMode}
                                                        onChange={(event) => {
                                                            const value = event.target.value;
                                                            setVideoExportMode(value);
                                                            localStorage.setItem("sketchydraw.videoExportMode", value);
                                                        }}
                                                    >
                                                        <option value="server">Server MP4 (recommended)</option>
                                                        <option value="browser">Browser WebM</option>
                                                    </select>
                                                </label>

                                                <button type="button" onClick={() => runProOnly("Video export", runVideoExport)} disabled={videoExportState.exporting}>
                                                    {videoExportState.exporting
                                                        ? `⏳ ${Math.round(videoExportState.progress || 0)}%`
                                                        : (videoExportMode === "server" ? "🎬 Export MP4 on server" : "🎬 Export WebM in browser")}
                                                </button>
                                                {videoExportState.exporting && (
                                                    <div className="video-export-progress" role="status" aria-live="polite">
                                                        <progress max="100" value={Math.round(videoExportState.progress || 0)} />
                                                        <span>{videoExportState.status || "Exporting video..."}</span>
                                                    </div>
                                                )}
                                            </div>
                                        </details>
                                    ) : (
                                        <button type="button" className="export-pro-locked-row" onClick={() => requestProUpgrade("Video export")}>
                                            🎬 Export video <span className="pro-inline-badge">PRO</span>
                                        </button>
                                    )}
                                </div>
                            )}
                        </div>

                        <div className="grid-menu-wrap legacy-toolbar-menu" ref={gridRef}>
                            <button
                                type="button"
                                className="toolbar-dark-action grid-trigger-btn"
                                onClick={() => setGridOpen((v) => !v)}
                                title="Canvas grid style"
                            >
                                Grid <span>{currentGridLabel} ⌄</span>
                            </button>

                            {gridOpen && (
                                <div className="grid-dropdown">
                                    <button type="button" onClick={() => applyCanvasPattern("blank")}>
                                        ⬜ Blank
                                    </button>

                                    <button type="button" onClick={() => applyCanvasPattern("grid")}>
                                        #️⃣ Grid Lines
                                    </button>

                                    <button type="button" onClick={() => applyCanvasPattern("notebook")}>
                                        📓 Notebook Pages
                                    </button>

                                    {activePattern === "notebook" && (
                                        <>
                                            <div className="grid-dropdown-divider" />

                                            <div className="grid-dropdown-label">
                                                Notebook Pages: {canvasProps?.pageCount || DEFAULT_NOTEBOOK_PAGE_COUNT}
                                            </div>

                                            <button type="button" onClick={addNotebookPage}>
                                                ➕ Add Page
                                            </button>

                                            <button
                                                type="button"
                                                onClick={removeNotebookPage}
                                                disabled={(canvasProps?.pageCount || DEFAULT_NOTEBOOK_PAGE_COUNT) <= 1}
                                            >
                                                ➖ Remove Last Page
                                            </button>
                                        </>
                                    )}

                                    <button type="button" onClick={() => applyCanvasPattern("dots")}>
                                        ⠿ Dot Grid
                                    </button>

                                    <button type="button" onClick={() => applyCanvasPattern("blocks")}>
                                        ▦ Blocks
                                    </button>
                                </div>
                            )}
                        </div>

                        {announcement && (
                            <div className="topbar-announcement" title={announcement}>
                                {announcement}
                            </div>
                        )}
                    </div>

                    <div className="topbar-tools-row">
                        <div className="toolbar-canvas-strip" role="toolbar" aria-label="Drawing tools">
                            {TOOLBAR_TOOLS.map((item, index) => {
                                const Icon = item.icon;
                                return (
                                    <button
                                        key={item.id}
                                        type="button"
                                        className={`toolbar-canvas-tool ${tool === item.id ? "active" : ""}`}
                                        onClick={() => chooseToolbarTool(item)}
                                        title={`${item.label}${item.premium ? " · PRO" : ""}`}
                                        aria-label={item.label}
                                        aria-pressed={tool === item.id}
                                    >
                                        <Icon size={17} strokeWidth={1.9} />
                                        {index < 9 && <span className="toolbar-tool-shortcut">{index + 1}</span>}
                                        {item.premium && !proUser && <span className="toolbar-tool-pro">PRO</span>}
                                    </button>
                                );
                            })}

                            <span className="toolbar-strip-divider" aria-hidden="true" />

                            <button
                                type="button"
                                className="toolbar-more-tools"
                                onClick={() => openSidebarSection("animation")}
                                title="Animate selected object or text"
                                aria-label="Animation"
                            >
                                <Zap size={17} strokeWidth={1.9} />
                            </button>

                            <button type="button" className="toolbar-more-tools" onClick={() => openSidebarSection("draw")} title="Open all tools">
                                <MoreHorizontal size={18} />
                                <span>More tools</span>
                            </button>

                        </div>
                    </div>

                    <div className={`topbar-auth ${!loggedIn ? "logged-out" : "logged-in"}`}>
                        {!loggedIn ? (
                            <>
                                <button
                                    type="button"
                                    className="login-btn"
                                    onClick={() => setLoginOpen(true)}
                                >
                                    Login
                                </button>

                            </>
                        ) : (
                            <div className="profile-menu-wrap" ref={profileRef}>
                                <button
                                    type="button"
                                    className="profile-trigger"
                                    onClick={() => setProfileOpen((v) => !v)}
                                >
                                <span className="profile-avatar">
                                    {(user?.fullName || user?.email || "U").charAt(0).toUpperCase()}
                                </span>

                                    <span className="profile-email">
                                    {user?.email || user?.fullName || "My Account"}
                                </span>

                                    <span className={proUser ? "topbar-pro-pill" : "topbar-free-pill"}>
                                    {proUser ? "PRO" : "FREE"}
                                </span>

                                    <span className="profile-caret">⌄</span>
                                </button>

                                {profileOpen && (
                                    <div className="profile-dropdown">
                                        <div className="profile-signed-box">
                                            <span>SIGNED IN AS</span>

                                            <strong>
                                                {user?.email || user?.fullName || "User"}
                                            </strong>

                                            <div className={proUser ? "profile-plan-badge pro" : "profile-plan-badge free"}>
                                                {proUser ? "⭐ PRO ACTIVE" : "FREE PLAN"}
                                            </div>

                                            {proUser && expiryDate && (
                                                <small className="profile-plan-expiry">
                                                    Valid till {new Date(expiryDate).toLocaleDateString()}
                                                </small>
                                            )}

                                            {!proUser && (
                                                <small className="profile-plan-expiry">
                                                    Free exports include SketchyDraw watermark.
                                                </small>
                                            )}
                                        </div>

                                        <button
                                            type="button"
                                            className="profile-menu-item"
                                            onClick={openProfileModal}
                                        >
                                            👤 My Profile
                                        </button>

                                        <button
                                            type="button"
                                            className="profile-menu-item"
                                            onClick={triggerMyDrawings}
                                        >
                                            🖼️ My Drawings
                                        </button>

                                        <button
                                            type="button"
                                            className="profile-menu-item"
                                            onClick={openPaymentHistory}
                                        >
                                            🧾 Payment History
                                        </button>

                                        <button
                                            type="button"
                                            className="profile-menu-item"
                                            onClick={() => {
                                                setProfileOpen(false);
                                                setSubscriptionOpen(true);
                                            }}
                                        >
                                            {proUser ? "⭐ Manage Pro" : "⭐ Subscribe / Buy Credits"}
                                        </button>

                                        <div className="profile-menu-divider" />

                                        <button
                                            type="button"
                                            className="profile-menu-item logout-menu-item"
                                            onClick={handleLogout}
                                        >
                                            Logout
                                        </button>
                                    </div>
                                )}
                            </div>
                        )}
                    </div>
                </div>

            </div>

            <SketchyLoginModal
                open={loginOpen}
                onClose={() => {
                    setLoginOpen(false);
                    refreshAuthState();
                }}
                onLoginSuccess={(u) => {
                    setUser(u);
                    setLoggedIn(true);
                    setLoginOpen(false);

                    setTimeout(() => {
                        refreshSubscriptionStatus();
                    }, 0);
                }}
            />

            <ProfileModal
                open={profileModalOpen}
                user={user}
                proUser={proUser}
                subscriptionStatus={subscriptionStatus}
                profileName={profileName}
                profileMessage={profileMessage}
                setProfileName={setProfileName}
                onSubmit={saveProfileName}
                onClose={() => setProfileModalOpen(false)}
            />

            <PaymentHistoryModal
                open={paymentsModalOpen}
                rows={paymentRows}
                loading={paymentLoading}
                onClose={() => setPaymentsModalOpen(false)}
            />

            <SubscriptionPopup
                open={subscriptionOpen}
                onClose={() => {
                    setSubscriptionOpen(false);
                    refreshSubscriptionStatus();
                }}
                onLoginRequired={() => {
                    setSubscriptionOpen(false);
                    setLoginOpen(true);
                }}
            />
        </>
    );
}

function ProfileModal({
                          open,
                          user,
                          proUser,
                          subscriptionStatus,
                          profileName,
                          profileMessage,
                          setProfileName,
                          onSubmit,
                          onClose,
                      }) {
    if (!open) return null;

    const expiryDate =
        user?.subscription?.endsAt ||
        subscriptionStatus?.endsAt ||
        subscriptionStatus?.endDate ||
        subscriptionStatus?.validTill ||
        null;

    const openMyDrawingsFromProfile = () => {
        onClose?.();

        setTimeout(() => {
            window.dispatchEvent(new Event("sketchydraw:open-my-drawings"));
        }, 0);
    };

    return (
        <div className="account-modal-backdrop" onMouseDown={onClose}>
            <div className="account-modal" onMouseDown={(e) => e.stopPropagation()}>
                <button type="button" className="account-modal-close" onClick={onClose}>
                    ×
                </button>

                <div className="account-modal-header">
                    <span className={proUser ? "account-status-badge pro" : "account-status-badge free"}>
                        {proUser ? "⭐ SketchyDraw Pro" : "Free Plan"}
                    </span>

                    <h2>My Profile</h2>
                    <p>{user?.email}</p>
                </div>

                <div className="account-status-card">
                    <strong>
                        {proUser
                            ? "Your Pro subscription is active."
                            : "You are currently on the Free plan."}
                    </strong>

                    {proUser && expiryDate && (
                        <span>
                            Valid till {new Date(expiryDate).toLocaleString()}
                        </span>
                    )}

                    {!proUser && (
                        <span>Free exports include a SketchyDraw watermark.</span>
                    )}
                </div>

                <div className="account-profile-actions">
                    <button
                        type="button"
                        className="account-secondary-btn"
                        onClick={openMyDrawingsFromProfile}
                    >
                        🖼️ Open My Drawings
                    </button>
                </div>

                <form onSubmit={onSubmit} className="account-form">
                    <label>
                        <span>Name</span>
                        <input
                            value={profileName || ""}
                            onChange={(e) => setProfileName(e.target.value)}
                            placeholder="Enter your name"
                            minLength={2}
                            maxLength={120}
                            required
                        />
                    </label>

                    <label>
                        <span>Email</span>
                        <input value={user?.email || ""} disabled />
                    </label>

                    {profileMessage && (
                        <div className="account-modal-message">
                            {profileMessage}
                        </div>
                    )}

                    <button type="submit" className="account-primary-btn">
                        Save Profile
                    </button>
                </form>
            </div>
        </div>
    );
}

function PaymentHistoryModal({ open, rows, loading, onClose }) {
    if (!open) return null;

    return (
        <div className="account-modal-backdrop" onMouseDown={onClose}>
            <div
                className="account-modal account-modal-wide"
                onMouseDown={(e) => e.stopPropagation()}
            >
                <button type="button" className="account-modal-close" onClick={onClose}>
                    ×
                </button>

                <div className="account-modal-header">
                    <span className="account-status-badge pro">🧾 Billing</span>
                    <h2>Payment History</h2>
                    <p>All your SketchyDraw payment attempts and successful payments.</p>
                </div>

                {loading ? (
                    <div className="account-empty-state">Loading payment history...</div>
                ) : rows.length === 0 ? (
                    <div className="account-empty-state">No successful payments found yet.</div>
                ) : (
                    <div className="payment-history-table-wrap">
                        <table className="payment-history-table">
                            <thead>
                            <tr>
                                <th>Date</th>
                                <th>Amount</th>
                                <th>Status</th>
                                <th>Order ID</th>
                            </tr>
                            </thead>

                            <tbody>
                            {rows.map((row, index) => (
                                <tr key={row.id || row.providerOrderId || row.orderId || index}>
                                    <td>
                                        {row.createdAt
                                            ? new Date(row.createdAt).toLocaleString()
                                            : row.created_at
                                                ? new Date(row.created_at).toLocaleString()
                                                : "-"}
                                    </td>

                                    <td>
                                        {row.currency || "INR"}{" "}
                                        {Number(row.amount || row.amountInRupees || 0).toLocaleString("en-IN")}
                                    </td>

                                    <td>
                                            <span className={`payment-status ${String(row.status || "").toLowerCase()}`}>
                                                {row.status || "-"}
                                            </span>
                                    </td>

                                    <td>
                                        {row.providerOrderId ||
                                            row.orderId ||
                                            row.razorpayOrderId ||
                                            "-"}
                                    </td>
                                </tr>
                            ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>
        </div>
    );
}
